#!/data/data/com.sccriv.vscode/files/usr/bin/sh

echo "$@"
